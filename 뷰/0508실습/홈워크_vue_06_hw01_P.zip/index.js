// store/index.js

export default new __(a)__({
  state: {
    count: 0,
  },
  mutations: {
    NUMBER_INCREMENT: function (state) {
      __(b)__
    },
  },
  actions: {
    numberIncrement: function (context) {
      __(c)__
    },
  },
})