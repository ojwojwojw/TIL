// App.vue

export default {
  name: 'App',
  created: function () {
    __(b)__
  },
}